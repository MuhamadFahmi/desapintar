# test-boot2-compatibility

Runs all test under SpringBoot 2.x (Spring 5.x) environment.

See build.gradle for details.
